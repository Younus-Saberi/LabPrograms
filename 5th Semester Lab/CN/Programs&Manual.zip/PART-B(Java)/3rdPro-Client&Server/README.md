# Output for above program

<img src="res/output.png">
