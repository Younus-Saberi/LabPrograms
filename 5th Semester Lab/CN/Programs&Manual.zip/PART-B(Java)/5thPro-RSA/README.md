# Output

<img src="res/output.png">